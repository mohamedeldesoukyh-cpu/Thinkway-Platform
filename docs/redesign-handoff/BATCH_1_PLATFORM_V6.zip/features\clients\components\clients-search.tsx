"use client";

import { OperationalTableSearch } from "@/components/tables/operational-table-search";

export function ClientsSearch() {
  return <OperationalTableSearch placeholder="Search clients..." />;
}
