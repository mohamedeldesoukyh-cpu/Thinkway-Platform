import { Suspense } from "react";

import { PlatformErrorBoundary } from "@/components/platform/error-boundary";
import { PlatformV6Page, PlatformV6PageHeader } from "@/components/platform/platform-v6-layout";
import { DashboardShell } from "@/components/layout/dashboard-shell";
import { ExecutiveDashboardView } from "@/features/executive-dashboard/components/executive-dashboard-view";
import {
  loadDashboardFilterOptions,
  loadExecutiveDashboard,
} from "@/features/analytics/load-executive-dashboard";
import {
  dashboardFiltersToAnalytics,
  parseDashboardSearchParams,
} from "@/lib/analytics/dashboard-filters";

type PageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function ExecutiveDashboardPage({ searchParams }: PageProps) {
  const params = await searchParams;
  const filterState = parseDashboardSearchParams(params);
  const analyticsFilters = dashboardFiltersToAnalytics(filterState);

  let errorMessage: string | null = null;
  let payload = null;
  let filterOptions = null;

  try {
    [payload, filterOptions] = await Promise.all([
      loadExecutiveDashboard(analyticsFilters),
      loadDashboardFilterOptions(),
    ]);
  } catch (error) {
    errorMessage =
      error instanceof Error ? error.message : "Failed to load executive dashboard.";
  }

  return (
    <DashboardShell
      title="Executive dashboard"
      description="CFO-grade finance monitoring — revenue, profitability, collections, and operational exposure."
      platformV6
      workspaceNavActive="finance"
    >
      <PlatformV6Page>
        <PlatformV6PageHeader
          title="Executive dashboard"
          description="CFO-grade finance monitoring — revenue, profitability, collections, and operational exposure."
        />

        {errorMessage ? (
          <div className="rounded-xl border border-destructive/30 bg-destructive/10 px-4 py-3 text-[11px] text-destructive">
            {errorMessage}
          </div>
        ) : payload && filterOptions ? (
          <Suspense
            fallback={
              <div className="space-y-4">
                <div className="h-14 animate-pulse rounded-2xl bg-muted" />
                <div className="h-32 animate-pulse rounded-2xl bg-muted" />
              </div>
            }
          >
            <PlatformErrorBoundary surface="executive">
              <ExecutiveDashboardView data={payload} filterOptions={filterOptions} />
            </PlatformErrorBoundary>
          </Suspense>
        ) : null}
      </PlatformV6Page>
    </DashboardShell>
  );
}
