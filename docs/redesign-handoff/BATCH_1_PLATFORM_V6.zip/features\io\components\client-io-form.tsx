"use client";

import { useActionState, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { OperationalTableSection } from "@/components/ui/operational-table-section";
import {
  DETAIL_FORM_INPUT_CLASS,
  DetailFormSection,
  DetailSheetFooter,
} from "@/features/campaigns/components/operational-detail-panel";
import { updateClientIoAction } from "@/features/io/actions";
import { generateClientIoDocumentAction } from "@/features/io/generate-client-io-document-action";
import { IoStatusBadge } from "@/features/io/components/io-status-badge";
import { ClientIoViewMenu } from "@/features/io/components/client-io-view-menu";
import { ClientIoEmailPreviewSection } from "@/features/io/components/client-io-email-preview";
import { ClientIoRecipientsEditor } from "@/features/io/components/client-io-recipients-editor";
import { ClientIoSendControls } from "@/features/io/components/client-io-send-controls";
import { ClientIoSendHistory } from "@/features/io/components/client-io-send-history";
import { ClientIoTermsEditorField } from "@/features/io/components/client-io-terms-editor";
import type { ClientIoRow, ClientIoSendHistoryEntry, ClientIoSendRecipient } from "@/features/io/types";
import {
  parseSendRecipientsJson,
  seedRecipientsFromContacts,
  serializeSendRecipients,
  type ClientIoRecipientEntry,
} from "@/lib/io/client-io-send-recipients";
import {
  parseTermsText,
  resolveDefaultTermsForClient,
  serializeTermsText,
  termsAreEqual,
  type ClientIoTerm,
} from "@/lib/io/client-io-terms";

const INITIAL_STATE = { ok: false } as const;

type Props = {
  row: ClientIoRow;
  recipients: ClientIoSendRecipient[];
  sendHistory?: ClientIoSendHistoryEntry[];
  senderName?: string | null;
  clientDefaultTermsText?: string | null;
  brandName?: string | null;
};

function SummaryItem({ label, value }: { label: string; value: string | null | undefined }) {
  return (
    <div className="space-y-0.5">
      <dt className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
        {label}
      </dt>
      <dd className="text-sm text-foreground">{value?.trim() || "—"}</dd>
    </div>
  );
}

export function ClientIoForm({
  row,
  recipients,
  sendHistory = [],
  senderName = null,
  clientDefaultTermsText = null,
  brandName = null,
}: Props) {
  const defaultTerms = useMemo(
    () => resolveDefaultTermsForClient(clientDefaultTermsText),
    [clientDefaultTermsText]
  );

  const initialTerms = useMemo(() => {
    return parseTermsText(row.terms_text) ?? defaultTerms;
  }, [row.terms_text, defaultTerms]);

  const [terms, setTerms] = useState<ClientIoTerm[]>(initialTerms);
  const [useDefaultTerms, setUseDefaultTerms] = useState(() => !parseTermsText(row.terms_text));
  const [billingTerms, setBillingTerms] = useState(row.billing_terms ?? "");
  const [attachmentUrl, setAttachmentUrl] = useState(row.attachment_url ?? "");
  const [sendRecipients, setSendRecipients] = useState<ClientIoRecipientEntry[]>(() =>
    seedRecipientsFromContacts(
      parseSendRecipientsJson(row.send_recipients),
      recipients.map((r) => ({ label: r.label, email: r.email }))
    )
  );

  const [saveState, saveAction, saving] = useActionState(updateClientIoAction, INITIAL_STATE);
  const [generateState, generateAction, generating] = useActionState(
    generateClientIoDocumentAction,
    INITIAL_STATE
  );

  useEffect(() => {
    setTerms(parseTermsText(row.terms_text) ?? defaultTerms);
    setUseDefaultTerms(!parseTermsText(row.terms_text));
    setBillingTerms(row.billing_terms ?? "");
    setAttachmentUrl(row.attachment_url ?? "");
    setSendRecipients(parseSendRecipientsJson(row.send_recipients));
  }, [row, defaultTerms]);

  useEffect(() => {
    if (!saveState.message) return;
    if (saveState.ok) toast.success(saveState.message);
    else toast.error(saveState.message);
  }, [saveState]);

  useEffect(() => {
    if (!generateState.message) return;
    if (generateState.ok) toast.success(generateState.message);
    else toast.error(generateState.message);
  }, [generateState]);

  const hasDocument = Boolean(
    row.document_generated_at || row.generated_html_url || row.terms_html
  );

  const sendRecipientsPayload = useMemo(
    () => serializeSendRecipients(sendRecipients),
    [sendRecipients]
  );

  const termsTextPayload = useMemo(() => {
    if (useDefaultTerms || termsAreEqual(terms, defaultTerms)) {
      return "";
    }
    return serializeTermsText(terms);
  }, [terms, defaultTerms, useDefaultTerms]);

  function handleTermsChange(nextTerms: ClientIoTerm[]) {
    setTerms(nextTerms);
    setUseDefaultTerms(false);
  }

  function handleRecoverTerms() {
    setTerms(defaultTerms);
    setUseDefaultTerms(true);
    toast.message("Terms reset to default. Save draft to apply.");
  }

  return (
    <OperationalTableSection
      wide
      tableOnly
      cardSurface
      leading={
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-sm font-semibold tracking-tight text-foreground">
            Client IO · {row.campaign_name}
            {row.document_number ? ` · ${row.document_number}` : null}
          </h2>
          <div className="inline-flex flex-wrap items-center gap-2">
            <IoStatusBadge status={row.status} />
            {hasDocument ? <ClientIoViewMenu clientIoId={row.id} /> : null}
          </div>
        </div>
      }
    >
      <form id="client-io-save" action={saveAction} className="flex flex-col">
        <input type="hidden" name="id" value={row.id} />
        <input type="hidden" name="campaign_header_id" value={row.campaign_header_id} />
        <input type="hidden" name="status" value={row.status} />
        <input type="hidden" name="terms_text" value={termsTextPayload} />
        <input type="hidden" name="send_recipients" value={sendRecipientsPayload} />

        <div className="px-6 py-4">
          <div className="space-y-1">
            <DetailFormSection label="Document details" className="py-3.5">
              <dl className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                <SummaryItem label="Document number" value={row.document_number} />
                <SummaryItem label="Campaign" value={row.campaign_name} />
                <SummaryItem label="Client" value={row.client_name} />
                <SummaryItem label="Brand" value={brandName} />
                <SummaryItem label="Status" value={row.status} />
                <SummaryItem label="Billing terms" value={billingTerms || row.billing_terms} />
              </dl>
            </DetailFormSection>

            <ClientIoRecipientsEditor
              recipients={sendRecipients}
              onChange={setSendRecipients}
              disabled={saving}
            />

            <ClientIoEmailPreviewSection
              io={row}
              senderName={senderName}
              recipients={sendRecipients}
              hasDocument={hasDocument}
            />

            <ClientIoTermsEditorField
              label="Terms & conditions"
              terms={terms}
              onChange={handleTermsChange}
              onRecover={handleRecoverTerms}
              description="Structured terms injected into Section 8 of the Client IO template. Leave as default or customize per IO."
            />

            <DetailFormSection label="Billing terms" className="py-3.5">
              <Input
                id="billing_terms"
                name="billing_terms"
                value={billingTerms}
                onChange={(e) => setBillingTerms(e.target.value)}
                placeholder="Net 30, invoicing notes..."
                className={DETAIL_FORM_INPUT_CLASS}
              />
            </DetailFormSection>

            <DetailFormSection label="Attachment URL (PO/SOW/PDF)" className="py-3.5">
              <Input
                id="attachment_url"
                name="attachment_url"
                value={attachmentUrl}
                onChange={(e) => setAttachmentUrl(e.target.value)}
                placeholder="https://..."
                className={DETAIL_FORM_INPUT_CLASS}
              />
            </DetailFormSection>

            <ClientIoSendHistory history={sendHistory} />
          </div>
        </div>
      </form>

      <form id="client-io-generate" action={generateAction} className="hidden">
        <input type="hidden" name="id" value={row.id} />
        <input type="hidden" name="campaign_header_id" value={row.campaign_header_id} />
      </form>

      <DetailSheetFooter>
        <div className="flex w-full flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap items-center gap-2">
            <Button
              form="client-io-generate"
              type="submit"
              variant="outline"
              size="sm"
              disabled={generating}
            >
              {generating
                ? "Generating…"
                : hasDocument
                  ? "Regenerate document"
                  : "Generate document"}
            </Button>
            <ClientIoSendControls
              io={row}
              campaignId={row.campaign_header_id}
              sendRecipientsJson={sendRecipientsPayload}
              recipientCount={sendRecipients.filter((r) => r.email.trim()).length}
              hasDocument={hasDocument}
            />
          </div>
          <Button
            form="client-io-save"
            type="submit"
            variant="outline"
            size="sm"
            disabled={saving}
          >
            {saving ? "Saving…" : "Save draft"}
          </Button>
        </div>
      </DetailSheetFooter>
    </OperationalTableSection>
  );
}
